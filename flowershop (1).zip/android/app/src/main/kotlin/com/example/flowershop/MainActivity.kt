package com.example.flowershop

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
