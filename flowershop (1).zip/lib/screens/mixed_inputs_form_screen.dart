import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class MixedInputsFormScreen extends StatefulWidget {
  const MixedInputsFormScreen({super.key});

  @override
  State<MixedInputsFormScreen> createState() => _MixedInputsFormScreenState();
}

class _MixedInputsFormScreenState extends State<MixedInputsFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _noteController = TextEditingController();
  bool _giftWrap = false;
  bool _subscribe = true;

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      Provider.of<AppState>(context, listen: false).saveOrderPreferences(
        note: _noteController.text.trim(),
        giftWrap: _giftWrap,
        subscribe: _subscribe,
      );
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preferences saved for future orders')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Order Preferences'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _noteController,
              decoration: const InputDecoration(
                labelText: 'Order note / special instructions',
                hintText: 'e.g., Write a short greeting card',
                prefixIcon: Icon(Icons.sticky_note_2_outlined),
              ),
            ),
            const SizedBox(height: 16),
            CheckboxListTile(
              value: _giftWrap,
              onChanged: (value) {
                setState(() {
                  _giftWrap = value ?? false;
                });
              },
              title: const Text('Include gift wrap'),
              controlAffinity: ListTileControlAffinity.leading,
              contentPadding: EdgeInsets.zero,
              subtitle: const Text('Adds a decorative wrap to your bouquet'),
            ),
            const SizedBox(height: 8),
            SwitchListTile(
              value: _subscribe,
              onChanged: (value) {
                setState(() {
                  _subscribe = value;
                });
              },
              title: const Text('Subscribe to order updates'),
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submit,
                child: const Text('Save Preferences'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
