import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import 'orders/orders_screen.dart';
import 'reservations/reservations_screen.dart';
// Documents are admin-side only
import 'simple_form_screen.dart';
import 'login_form_screen.dart';
import 'mixed_inputs_form_screen.dart';
import 'products_screen.dart';
import 'cart_screen.dart';
import 'local_list_demo_screen.dart';
import 'orders/new_order_screen.dart';
import 'reservations/new_reservation_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const DashboardScreen(),
    const ProductsScreen(),
    const OrdersScreen(),
    const ReservationsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              UserAccountsDrawerHeader(
                accountName: const Text('Stephanie David'),
                accountEmail: const Text('stephanie.david@example.com'),
                currentAccountPicture: const CircleAvatar(
                  backgroundImage: NetworkImage(
                      'https://images.unsplash.com/photo-1520813792240-56fc4a3765a7?w=400'),
                ),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                ),
              ),
              ListTile(
                leading: const Icon(Icons.dashboard),
                title: const Text('Dashboard'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _currentIndex = 0);
                },
              ),
              ListTile(
                leading: const Icon(Icons.local_florist),
                title: const Text('Shop'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _currentIndex = 1);
                },
              ),
              ListTile(
                leading: const Icon(Icons.shopping_cart),
                title: const Text('Orders'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _currentIndex = 2);
                },
              ),
              ListTile(
                leading: const Icon(Icons.event),
                title: const Text('Reservations'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _currentIndex = 3);
                },
              ),
              ListTile(
                leading: const Icon(Icons.assignment_outlined),
                title: const Text('Simple Form'),
                subtitle: const Text('Enter username'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const SimpleFormScreen(),
                    ),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.tune),
                title: const Text('Preferences Form'),
                subtitle: const Text('TextField, Checkbox, Switch'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const MixedInputsFormScreen(),
                    ),
                  );
                },
              ),
              // Documents and Cart are not in customer tabs
            ],
          ),
        ),
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.local_florist),
            label: 'Shop',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'Orders',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.event),
            label: 'Reservations',
          ),
        ],
      ),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flower Shop Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Provider.of<AppState>(context, listen: false).logout();
            },
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome to Flower Shop!',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 8),
              Text(
                'Manage your orders, reservations, and documents',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.grey[600],
                    ),
              ),
              const SizedBox(height: 24),

              // Quick Stats
              Consumer<AppState>(
                builder: (context, appState, child) {
                  return Row(
                    children: [
                      Expanded(
                        child: _StatCard(
                          title: 'Orders',
                          count: appState.orders.length,
                          icon: Icons.shopping_cart,
                          color: Colors.blue,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _StatCard(
                          title: 'Reservations',
                          count: appState.reservations.length,
                          icon: Icons.event,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 16),
              // Revenue removed from user dashboard; available on admin home only
              const SizedBox(height: 32),

              // Featured Flowers
              Text(
                'Featured Flowers',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 180,
                child: Consumer<AppState>(
                  builder: (context, appState, _) {
                    final products = appState.products;
                    if (products.isEmpty) {
                      return Center(
                        child: Text(
                          'No products yet',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(color: Colors.grey[600]),
                        ),
                      );
                    }
                    return ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: products.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (context, index) {
                        final p = products[index];
                        return SizedBox(
                          width: 160,
                          child: Card(
                            clipBehavior: Clip.antiAlias,
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => const ProductsScreen()),
                                );
                              },
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Image.network(
                                      p.imageUrl,
                                      width: double.infinity,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          p.name,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyMedium
                                              ?.copyWith(
                                                  fontWeight: FontWeight.w600),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          '₱${p.price.toStringAsFixed(2)}',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                  color: Theme.of(context)
                                                      .primaryColor),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
              // Promo banner
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AspectRatio(
                  aspectRatio: 16 / 6,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/banner/747_fbbyCYyL19phuHaxE8IwZnUxx.webp',
                        fit: BoxFit.cover,
                      ),
                      Container(color: Colors.black26),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'Seasonal Sale',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineSmall
                                  ?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Get fresh bouquets for every occasion',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // Categories chips
              Text(
                'Popular Categories',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: const [
                  Chip(
                    avatar: Icon(Icons.favorite, size: 16, color: Colors.white),
                    label: Text('Roses', style: TextStyle(color: Colors.white)),
                    backgroundColor: Colors.red,
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  ),
                  Chip(
                    avatar: Icon(Icons.wb_sunny, size: 16, color: Colors.white),
                    label: Text('Sunflowers',
                        style: TextStyle(color: Colors.white)),
                    backgroundColor: Colors.amber,
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  ),
                  Chip(
                    avatar: Icon(Icons.spa, size: 16, color: Colors.white),
                    label:
                        Text('Lilies', style: TextStyle(color: Colors.white)),
                    backgroundColor: Colors.purple,
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  ),
                  Chip(
                    avatar: Icon(Icons.local_florist,
                        size: 16, color: Colors.white),
                    label:
                        Text('Tulips', style: TextStyle(color: Colors.white)),
                    backgroundColor: Colors.pink,
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  ),
                  Chip(
                    avatar: Icon(Icons.style, size: 16, color: Colors.white),
                    label:
                        Text('Bouquets', style: TextStyle(color: Colors.white)),
                    backgroundColor: Colors.teal,
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.tune),
                      title: const Text('Preferences Form'),
                      subtitle: const Text('TextField, Checkbox, Switch'),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const MixedInputsFormScreen(),
                          ),
                        );
                      },
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.assignment_outlined),
                      title: const Text('Simple Form'),
                      subtitle: const Text('Enter username'),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const SimpleFormScreen(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              // Recent Orders
              Consumer<AppState>(
                builder: (context, appState, _) {
                  final recent = appState.orders.take(3).toList();
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.receipt_long),
                              const SizedBox(width: 8),
                              Text('Recent Orders',
                                  style:
                                      Theme.of(context).textTheme.titleMedium),
                            ],
                          ),
                          const SizedBox(height: 8),
                          if (recent.isEmpty)
                            Text('No orders yet',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(color: Colors.grey[600]))
                          else
                            ...recent.map((o) => ListTile(
                                  dense: true,
                                  contentPadding: EdgeInsets.zero,
                                  title: Text(o.customerName,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis),
                                  subtitle: Text(
                                      '₱${o.totalAmount.toStringAsFixed(2)}'),
                                  trailing: const Icon(Icons.chevron_right),
                                )),
                        ],
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 16),
              // Upcoming Reservations
              Consumer<AppState>(
                builder: (context, appState, _) {
                  final upcoming = appState.reservations
                      .where((r) => r.reservationDate.isAfter(
                          DateTime.now().subtract(const Duration(days: 1))))
                      .take(3)
                      .toList();
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.event_available),
                              const SizedBox(width: 8),
                              Text('Upcoming Reservations',
                                  style:
                                      Theme.of(context).textTheme.titleMedium),
                            ],
                          ),
                          const SizedBox(height: 8),
                          if (upcoming.isEmpty)
                            Text('No reservations yet',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(color: Colors.grey[600]))
                          else
                            ...upcoming.map((r) => ListTile(
                                  dense: true,
                                  contentPadding: EdgeInsets.zero,
                                  title: Text(r.eventType),
                                  subtitle: Text(
                                      '${r.customerName} • ${r.timeSlot} • ${r.reservationDate.day}/${r.reservationDate.month}'),
                                )),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  double _calculateRevenue(List orders) {
    return orders.fold(0.0, (sum, order) => sum + order.totalAmount);
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final dynamic count;
  final IconData icon;
  final Color color;
  final bool isCurrency;

  const _StatCard({
    required this.title,
    required this.count,
    required this.icon,
    required this.color,
    this.isCurrency = false,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 24),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.grey[600],
                      ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              isCurrency ? '₱${count.toStringAsFixed(2)}' : count.toString(),
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: color,
                    fontWeight: FontWeight.bold,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _ActionCard({
    required this.title,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Icon(icon, color: color, size: 32),
              const SizedBox(height: 8),
              Text(
                title,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// _CategoryChip removed; using inline Chip widgets above
