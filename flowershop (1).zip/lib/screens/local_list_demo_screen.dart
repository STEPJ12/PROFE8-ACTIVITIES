import 'package:flutter/material.dart';

class LocalListDemoScreen extends StatefulWidget {
  const LocalListDemoScreen({super.key});

  @override
  State<LocalListDemoScreen> createState() => _LocalListDemoScreenState();
}

class _LocalListDemoScreenState extends State<LocalListDemoScreen> {
  // Part 1: Capture text using a controller and show after button press
  final TextEditingController _captureController = TextEditingController();
  String _capturedText = '';

  // Part 2: Simple form that saves entries to a local list and displays them
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _noteController = TextEditingController();
  final List<Map<String, String>> _entries = [];

  @override
  void dispose() {
    _captureController.dispose();
    _nameController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  void _capture() {
    setState(() {
      _capturedText = _captureController.text.trim();
    });
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _entries.add({
          'name': _nameController.text.trim(),
          'note': _noteController.text.trim(),
        });
        _nameController.clear();
        _noteController.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Local List & Capture Demo')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Capture section
          Text('Capture text with controller',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _captureController,
                  decoration: const InputDecoration(
                    labelText: 'Type something',
                    prefixIcon: Icon(Icons.edit),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(onPressed: _capture, child: const Text('Show')),
            ],
          ),
          if (_capturedText.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.06),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('You typed: $_capturedText'),
            ),
          ],
          const SizedBox(height: 24),

          // Form section
          Text('Save entries to a local list',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Name',
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty)
                      ? 'Please enter a name'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _noteController,
                  decoration: const InputDecoration(
                    labelText: 'Note (optional)',
                    prefixIcon: Icon(Icons.note_alt_outlined),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _submitForm,
                    child: const Text('Add Entry'),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          if (_entries.isEmpty)
            const Text('No entries yet.')
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _entries.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final e = _entries[index];
                return ListTile(
                  leading: const Icon(Icons.local_florist),
                  title: Text(e['name'] ?? ''),
                  subtitle: (e['note']?.isNotEmpty ?? false)
                      ? Text(e['note']!)
                      : null,
                );
              },
            ),
        ],
      ),
    );
  }
}
