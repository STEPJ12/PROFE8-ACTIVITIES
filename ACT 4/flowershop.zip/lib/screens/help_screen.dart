import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Help & Support'),
        backgroundColor: Colors.teal[600],
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Quick Help Section
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.help_outline,
                            color: Colors.teal[600], size: 28),
                        const SizedBox(width: 12),
                        Text(
                          'Quick Help',
                          style:
                              Theme.of(context).textTheme.titleLarge?.copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Need immediate assistance? Check our frequently asked questions or contact our support team.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.grey[600],
                          ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // FAQ Section
            Text(
              'Frequently Asked Questions',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12),

            Card(
              child: Column(
                children: [
                  _buildFAQItem(
                    context,
                    'How do I place an order?',
                    'To place an order, browse our products, add items to your cart, and proceed to checkout.',
                    Icons.shopping_cart,
                    Colors.blue,
                  ),
                  const Divider(height: 1),
                  _buildFAQItem(
                    context,
                    'How can I track my order?',
                    'You can track your order in the Orders section of the app or check your email for updates.',
                    Icons.local_shipping,
                    Colors.green,
                  ),
                  const Divider(height: 1),
                  _buildFAQItem(
                    context,
                    'What payment methods do you accept?',
                    'We accept credit cards, debit cards, PayPal, and Apple Pay.',
                    Icons.payment,
                    Colors.orange,
                  ),
                  const Divider(height: 1),
                  _buildFAQItem(
                    context,
                    'How do I cancel an order?',
                    'You can cancel an order within 24 hours of placement in the Orders section.',
                    Icons.cancel,
                    Colors.red,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Contact Support
            Text(
              'Contact Support',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12),

            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.phone, color: Colors.green),
                    title: const Text('Phone Support'),
                    subtitle: const Text('+1 (555) 123-4567'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      // Handle phone call
                    },
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.email, color: Colors.blue),
                    title: const Text('Email Support'),
                    subtitle: const Text('support@flowershop.com'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      // Handle email
                    },
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.chat, color: Colors.purple),
                    title: const Text('Live Chat'),
                    subtitle: const Text('Chat with our support team'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      // Handle live chat
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Help Topics
            Text(
              'Help Topics',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12),

            Card(
              child: Column(
                children: [
                  ListTile(
                    leading:
                        const Icon(Icons.account_circle, color: Colors.indigo),
                    title: const Text('Account Management'),
                    subtitle: const Text(
                        'Manage your account settings and preferences'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      // Navigate to account help
                    },
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading:
                        const Icon(Icons.shopping_bag, color: Colors.orange),
                    title: const Text('Ordering & Delivery'),
                    subtitle:
                        const Text('Learn about placing and tracking orders'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      // Navigate to ordering help
                    },
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.payment, color: Colors.green),
                    title: const Text('Payment & Billing'),
                    subtitle:
                        const Text('Payment methods and billing information'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      // Navigate to payment help
                    },
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.undo, color: Colors.red),
                    title: const Text('Returns & Refunds'),
                    subtitle: const Text('Return policy and refund process'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      // Navigate to returns help
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // App Information
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'App Information',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Version'),
                        Text(
                          '1.0.0',
                          style: TextStyle(color: Colors.grey[600]),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Last Updated'),
                        Text(
                          'December 2024',
                          style: TextStyle(color: Colors.grey[600]),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 30),

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      // Handle contact support
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Opening support chat...'),
                          backgroundColor: Colors.teal,
                        ),
                      );
                    },
                    icon: const Icon(Icons.chat),
                    label: const Text('Contact Support'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal[600],
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      // Handle feedback
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Opening feedback form...'),
                          backgroundColor: Colors.teal,
                        ),
                      );
                    },
                    icon: const Icon(Icons.feedback),
                    label: const Text('Send Feedback'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.teal[600],
                      side: BorderSide(color: Colors.teal[600]!),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFAQItem(BuildContext context, String question, String answer,
      IconData icon, Color color) {
    return ExpansionTile(
      leading: Icon(icon, color: color),
      title: Text(
        question,
        style: const TextStyle(fontWeight: FontWeight.w500),
      ),
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Text(
            answer,
            style: TextStyle(
              color: Colors.grey[600],
              height: 1.4,
            ),
          ),
        ),
      ],
    );
  }
}
