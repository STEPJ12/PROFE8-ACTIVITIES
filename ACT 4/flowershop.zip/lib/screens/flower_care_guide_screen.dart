import 'package:flutter/material.dart';

class FlowerCareGuideScreen extends StatelessWidget {
  const FlowerCareGuideScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flower Care Guide'),
        backgroundColor: Colors.green[600],
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.local_offer),
            onPressed: () {
              Navigator.pushNamed(context, '/special_offers');
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Section
            Card(
              color: Colors.green[50],
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.eco, color: Colors.green[600], size: 32),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Keep Your Flowers Fresh',
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green[800],
                                ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Expert tips to make your flowers last longer',
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(
                                  color: Colors.green[700],
                                ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Quick Tips Section
            Text(
              'Essential Care Tips',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12),

            _CareTipCard(
              icon: Icons.water_drop,
              title: 'Water Daily',
              description: 'Change water every day and trim stems at an angle',
              color: Colors.blue,
            ),
            const SizedBox(height: 12),

            _CareTipCard(
              icon: Icons.wb_sunny,
              title: 'Avoid Direct Sunlight',
              description:
                  'Keep flowers in a cool, shaded area away from heat sources',
              color: Colors.orange,
            ),
            const SizedBox(height: 12),

            _CareTipCard(
              icon: Icons.cut,
              title: 'Trim Stems',
              description:
                  'Cut stems at 45-degree angle every 2-3 days for better water absorption',
              color: Colors.red,
            ),
            const SizedBox(height: 12),

            _CareTipCard(
              icon: Icons.thermostat,
              title: 'Cool Environment',
              description:
                  'Maintain room temperature between 65-75°F for optimal freshness',
              color: Colors.purple,
            ),
            const SizedBox(height: 24),

            // Flower-Specific Care
            Text(
              'Flower-Specific Care',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    _FlowerCareItem(
                      flower: 'Roses',
                      tip: 'Remove thorns and leaves below water line',
                      icon: Icons.local_florist,
                      color: Colors.red,
                    ),
                    const Divider(),
                    _FlowerCareItem(
                      flower: 'Tulips',
                      tip: 'Keep in cool water and avoid direct sunlight',
                      icon: Icons.eco,
                      color: Colors.orange,
                    ),
                    const Divider(),
                    _FlowerCareItem(
                      flower: 'Lilies',
                      tip: 'Remove pollen to prevent staining and extend life',
                      icon: Icons.auto_awesome,
                      color: Colors.pink,
                    ),
                    const Divider(),
                    _FlowerCareItem(
                      flower: 'Sunflowers',
                      tip: 'Change water frequently and keep stems clean',
                      icon: Icons.wb_sunny,
                      color: Colors.yellow,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Troubleshooting Section
            Text(
              'Common Issues',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    _TroubleshootItem(
                      problem: 'Flowers wilting quickly',
                      solution: 'Check water level and trim stems',
                      icon: Icons.warning,
                      color: Colors.red,
                    ),
                    const SizedBox(height: 12),
                    _TroubleshootItem(
                      problem: 'Water turning cloudy',
                      solution: 'Change water and clean vase thoroughly',
                      icon: Icons.water_drop,
                      color: Colors.blue,
                    ),
                    const SizedBox(height: 12),
                    _TroubleshootItem(
                      problem: 'Leaves turning yellow',
                      solution: 'Remove submerged leaves and trim regularly',
                      icon: Icons.eco,
                      color: Colors.green,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pushNamed(context, '/special_offers');
                    },
                    icon: const Icon(Icons.local_offer),
                    label: const Text('View Special Offers'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange[600],
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text(
                                'Contact support for personalized care tips!')),
                      );
                    },
                    icon: const Icon(Icons.support_agent),
                    label: const Text('Get Help'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _CareTipCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final Color color;

  const _CareTipCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: color,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[700],
                        ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FlowerCareItem extends StatelessWidget {
  final String flower;
  final String tip;
  final IconData icon;
  final Color color;

  const _FlowerCareItem({
    required this.flower,
    required this.tip,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  flower,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                Text(
                  tip,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.grey[600],
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TroubleshootItem extends StatelessWidget {
  final String problem;
  final String solution;
  final IconData icon;
  final Color color;

  const _TroubleshootItem({
    required this.problem,
    required this.solution,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                problem,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
              ),
              const SizedBox(height: 2),
              Text(
                'Solution: $solution',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                    ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
