import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Cart'),
      ),
      body: Consumer<AppState>(
        builder: (context, appState, child) {
          final cart = appState.cart;
          if (cart.isEmpty) {
            return const Center(child: Text('Your cart is empty'));
          }
          return Column(
            children: [
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: cart.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final item = cart[index];
                    return Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 64,
                              height: 64,
                              child: Image.network(item.product.imageUrl,
                                  fit: BoxFit.cover),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item.product.name,
                                    style:
                                        Theme.of(context).textTheme.titleMedium,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '₱${item.product.price.toStringAsFixed(2)} each',
                                    style:
                                        Theme.of(context).textTheme.bodySmall,
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    children: [
                                      IconButton(
                                        icon: const Icon(
                                            Icons.remove_circle_outline),
                                        onPressed: () {
                                          final newQty = item.quantity - 1;
                                          if (newQty <= 0) {
                                            appState.removeFromCart(
                                                item.product.id);
                                          } else {
                                            appState.updateCartQuantity(
                                                item.product.id, newQty);
                                          }
                                        },
                                      ),
                                      Text(item.quantity.toString()),
                                      IconButton(
                                        icon: const Icon(
                                            Icons.add_circle_outline),
                                        onPressed: () {
                                          appState.updateCartQuantity(
                                              item.product.id,
                                              item.quantity + 1);
                                        },
                                      ),
                                      const Spacer(),
                                      Text(
                                          '₱${item.lineTotal.toStringAsFixed(2)}'),
                                      IconButton(
                                        icon: const Icon(Icons.delete_outline),
                                        onPressed: () => appState
                                            .removeFromCart(item.product.id),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.05), blurRadius: 8)
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Total: ₱${appState.cartTotal.toStringAsFixed(2)}',
                        style: Theme.of(context)
                            .textTheme
                            .titleLarge
                            ?.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const CheckoutScreen()),
                        );
                      },
                      child: const Text('Checkout'),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  String _paymentMethod = 'Cash on Delivery';
  // Order preferences
  final TextEditingController _noteController = TextEditingController();
  bool _giftWrap = false;
  bool _subscribe = true;

  @override
  void dispose() {
    _nameController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _pay() async {
    if (!_formKey.currentState!.validate()) return;
    final appState = Provider.of<AppState>(context, listen: false);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    final order = await appState.checkoutCart(
      customerName: _nameController.text.trim(),
      customerEmail: 'customer@example.com',
      customerPhone: _phoneController.text.trim(),
      deliveryAddress: _addressController.text.trim(),
      paymentMethod: _paymentMethod,
    );
    if (mounted) Navigator.pop(context); // close progress
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content:
              Text('Order ${order.id.substring(0, 8)} placed successfully')),
    );
    Navigator.pop(context); // back to cart
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.read<AppState>();
    // Initialize defaults once from saved preferences
    _giftWrap = _giftWrap; // no-op to keep analyzer quiet
    final total = appState.cartTotal;
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Total to pay: ₱${total.toStringAsFixed(2)}',
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Full name'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _addressController,
              decoration: const InputDecoration(labelText: 'Delivery address'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Phone number'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 12),
            // Order preferences section
            Text('Order preferences',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            TextFormField(
              controller: _noteController,
              decoration: const InputDecoration(
                labelText: 'Order note / special instructions',
                prefixIcon: Icon(Icons.sticky_note_2_outlined),
              ),
            ),
            CheckboxListTile(
              value: _giftWrap,
              onChanged: (v) => setState(() => _giftWrap = v ?? false),
              title: const Text('Include gift wrap'),
              controlAffinity: ListTileControlAffinity.leading,
              contentPadding: EdgeInsets.zero,
            ),
            SwitchListTile(
              value: _subscribe,
              onChanged: (v) => setState(() => _subscribe = v),
              title: const Text('Subscribe to order updates'),
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _paymentMethod,
              decoration: const InputDecoration(labelText: 'Payment method'),
              items: const [
                DropdownMenuItem(
                    value: 'Cash on Delivery', child: Text('Cash on Delivery')),
                DropdownMenuItem(value: 'GCash', child: Text('GCash')),
                DropdownMenuItem(
                    value: 'Credit/Debit Card',
                    child: Text('Credit/Debit Card')),
              ],
              onChanged: (v) =>
                  setState(() => _paymentMethod = v ?? _paymentMethod),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  // Save preferences before paying
                  Provider.of<AppState>(context, listen: false)
                      .saveOrderPreferences(
                    note: _noteController.text.trim(),
                    giftWrap: _giftWrap,
                    subscribe: _subscribe,
                  );
                  await _pay();
                },
                child: const Text('Pay Now'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
