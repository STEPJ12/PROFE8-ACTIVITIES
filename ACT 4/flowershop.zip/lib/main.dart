import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
//import 'package:provider/app_state.dart';//
import 'providers/app_state.dart';
import 'screens/home_screen.dart';
import 'screens/admin_home_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/simple_form_screen.dart';
import 'screens/login_form_screen.dart';
import 'screens/about_screen.dart';
import 'screens/contact_screen.dart';
import 'utils/theme.dart';

void main() {
  runApp(const FlowerShopApp());
}

class FlowerShopApp extends StatelessWidget {
  const FlowerShopApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState()),
      ],
      child: MaterialApp(
        title: 'Flower Shop',
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        home: const AuthWrapper(),
        debugShowCheckedModeBanner: false,
        routes: {
          '/home': (context) => const HomeScreen(),
          '/about': (context) => const AboutScreen(),
          '/contact': (context) => const ContactScreen(),
        },
        onGenerateRoute: (settings) {
          // Handle any additional route generation if needed
          return null;
        },
      ),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, appState, child) {
        if (appState.isLoggedIn) {
          if (appState.currentRole == UserRole.admin) {
            return const AdminHomeScreen();
          }
          return const HomeScreen();
        } else {
          return const LoginScreen();
        }
      },
    );
  }
}
