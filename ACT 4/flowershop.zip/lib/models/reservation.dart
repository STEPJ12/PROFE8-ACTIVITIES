import 'package:uuid/uuid.dart';

class Reservation {
  final String id;
  final String customerName;
  final String customerEmail;
  final String customerPhone;
  final DateTime reservationDate;
  final String timeSlot;
  final String eventType;
  final String? specialRequests;
  final ReservationStatus status;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final double? estimatedCost;
  final PaymentInfo? paymentInfo;

  Reservation({
    String? id,
    required this.customerName,
    required this.customerEmail,
    required this.customerPhone,
    required this.reservationDate,
    required this.timeSlot,
    required this.eventType,
    this.specialRequests,
    this.status = ReservationStatus.pending,
    DateTime? createdAt,
    this.updatedAt,
    this.estimatedCost,
    this.paymentInfo,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'customerName': customerName,
      'customerEmail': customerEmail,
      'customerPhone': customerPhone,
      'reservationDate': reservationDate.toIso8601String(),
      'timeSlot': timeSlot,
      'eventType': eventType,
      'specialRequests': specialRequests,
      'status': status.name,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'estimatedCost': estimatedCost,
      'paymentInfo': paymentInfo?.toJson(),
    };
  }

  factory Reservation.fromJson(Map<String, dynamic> json) {
    return Reservation(
      id: json['id'],
      customerName: json['customerName'],
      customerEmail: json['customerEmail'],
      customerPhone: json['customerPhone'],
      reservationDate: DateTime.parse(json['reservationDate']),
      timeSlot: json['timeSlot'],
      eventType: json['eventType'],
      specialRequests: json['specialRequests'],
      status: ReservationStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => ReservationStatus.pending,
      ),
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt:
          json['updatedAt'] != null ? DateTime.parse(json['updatedAt']) : null,
      estimatedCost: json['estimatedCost']?.toDouble(),
      paymentInfo: json['paymentInfo'] != null
          ? PaymentInfo.fromJson(json['paymentInfo'])
          : null,
    );
  }

  Reservation copyWith({
    String? customerName,
    String? customerEmail,
    String? customerPhone,
    DateTime? reservationDate,
    String? timeSlot,
    String? eventType,
    String? specialRequests,
    ReservationStatus? status,
    DateTime? updatedAt,
    double? estimatedCost,
    PaymentInfo? paymentInfo,
  }) {
    return Reservation(
      id: id,
      customerName: customerName ?? this.customerName,
      customerEmail: customerEmail ?? this.customerEmail,
      customerPhone: customerPhone ?? this.customerPhone,
      reservationDate: reservationDate ?? this.reservationDate,
      timeSlot: timeSlot ?? this.timeSlot,
      eventType: eventType ?? this.eventType,
      specialRequests: specialRequests ?? this.specialRequests,
      status: status ?? this.status,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      estimatedCost: estimatedCost ?? this.estimatedCost,
      paymentInfo: paymentInfo ?? this.paymentInfo,
    );
  }
}

enum ReservationStatus {
  pending,
  confirmed,
  inProgress,
  completed,
  cancelled,
  noShow,
}

class PaymentInfo {
  final String paymentId;
  final PaymentMethod method;
  final PaymentStatus status;
  final double amount;
  final DateTime processedAt;
  final String? transactionId;

  PaymentInfo({
    required this.paymentId,
    required this.method,
    required this.status,
    required this.amount,
    required this.processedAt,
    this.transactionId,
  });

  Map<String, dynamic> toJson() {
    return {
      'paymentId': paymentId,
      'method': method.name,
      'status': status.name,
      'amount': amount,
      'processedAt': processedAt.toIso8601String(),
      'transactionId': transactionId,
    };
  }

  factory PaymentInfo.fromJson(Map<String, dynamic> json) {
    return PaymentInfo(
      paymentId: json['paymentId'],
      method: PaymentMethod.values.firstWhere(
        (e) => e.name == json['method'],
        orElse: () => PaymentMethod.cash,
      ),
      status: PaymentStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => PaymentStatus.pending,
      ),
      amount: json['amount'].toDouble(),
      processedAt: DateTime.parse(json['processedAt']),
      transactionId: json['transactionId'],
    );
  }
}

enum PaymentMethod {
  cash,
  card,
  bankTransfer,
  digitalWallet,
}

enum PaymentStatus {
  pending,
  processing,
  completed,
  failed,
  refunded,
}
