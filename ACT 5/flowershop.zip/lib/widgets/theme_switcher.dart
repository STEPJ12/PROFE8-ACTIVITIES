import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

/// A reusable theme switcher widget that can be used across all screens
class ThemeSwitcher extends StatelessWidget {
  final bool showLabel;
  final bool isCompact;

  const ThemeSwitcher({
    super.key,
    this.showLabel = true,
    this.isCompact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, child) {
        if (isCompact) {
          return _buildCompactSwitcher(context, themeProvider);
        } else {
          return _buildFullSwitcher(context, themeProvider);
        }
      },
    );
  }

  Widget _buildCompactSwitcher(
      BuildContext context, ThemeProvider themeProvider) {
    return IconButton(
      icon: Icon(
        themeProvider.isDarkMode ? Icons.light_mode : Icons.dark_mode,
        color: Theme.of(context).iconTheme.color,
      ),
      onPressed: () => themeProvider.toggleTheme(),
      tooltip: 'Toggle theme (${themeProvider.themeModeString})',
    );
  }

  Widget _buildFullSwitcher(BuildContext context, ThemeProvider themeProvider) {
    return PopupMenuButton<ThemeMode>(
      icon: Icon(
        themeProvider.isDarkMode ? Icons.dark_mode : Icons.light_mode,
        color: Theme.of(context).iconTheme.color,
      ),
      tooltip: 'Theme: ${themeProvider.themeModeString}',
      onSelected: (ThemeMode mode) => themeProvider.setThemeMode(mode),
      itemBuilder: (context) => [
        PopupMenuItem<ThemeMode>(
          value: ThemeMode.light,
          child: Row(
            children: [
              Icon(
                Icons.light_mode,
                color: themeProvider.themeMode == ThemeMode.light
                    ? Theme.of(context).primaryColor
                    : null,
              ),
              const SizedBox(width: 8),
              Text(
                'Light',
                style: TextStyle(
                  color: themeProvider.themeMode == ThemeMode.light
                      ? Theme.of(context).primaryColor
                      : null,
                  fontWeight: themeProvider.themeMode == ThemeMode.light
                      ? FontWeight.bold
                      : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
        PopupMenuItem<ThemeMode>(
          value: ThemeMode.dark,
          child: Row(
            children: [
              Icon(
                Icons.dark_mode,
                color: themeProvider.themeMode == ThemeMode.dark
                    ? Theme.of(context).primaryColor
                    : null,
              ),
              const SizedBox(width: 8),
              Text(
                'Dark',
                style: TextStyle(
                  color: themeProvider.themeMode == ThemeMode.dark
                      ? Theme.of(context).primaryColor
                      : null,
                  fontWeight: themeProvider.themeMode == ThemeMode.dark
                      ? FontWeight.bold
                      : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
        PopupMenuItem<ThemeMode>(
          value: ThemeMode.system,
          child: Row(
            children: [
              Icon(
                Icons.settings_suggest,
                color: themeProvider.themeMode == ThemeMode.system
                    ? Theme.of(context).primaryColor
                    : null,
              ),
              const SizedBox(width: 8),
              Text(
                'System',
                style: TextStyle(
                  color: themeProvider.themeMode == ThemeMode.system
                      ? Theme.of(context).primaryColor
                      : null,
                  fontWeight: themeProvider.themeMode == ThemeMode.system
                      ? FontWeight.bold
                      : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// A simple toggle button for quick theme switching
class ThemeToggleButton extends StatelessWidget {
  const ThemeToggleButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, child) {
        return Switch(
          value: themeProvider.isDarkMode,
          onChanged: (value) {
            themeProvider.setThemeMode(
              value ? ThemeMode.dark : ThemeMode.light,
            );
          },
        );
      },
    );
  }
}

/// A card widget showing current theme with options
class ThemeCard extends StatelessWidget {
  const ThemeCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, child) {
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      themeProvider.isDarkMode
                          ? Icons.dark_mode
                          : Icons.light_mode,
                      color: Theme.of(context).primaryColor,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Theme Settings',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Current: ${themeProvider.themeModeString}',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => themeProvider.setLightTheme(),
                        icon: const Icon(Icons.light_mode, size: 16),
                        label: const Text('Light'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              themeProvider.themeMode == ThemeMode.light
                                  ? Theme.of(context).primaryColor
                                  : null,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => themeProvider.setDarkTheme(),
                        icon: const Icon(Icons.dark_mode, size: 16),
                        label: const Text('Dark'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              themeProvider.themeMode == ThemeMode.dark
                                  ? Theme.of(context).primaryColor
                                  : null,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => themeProvider.setSystemTheme(),
                        icon: const Icon(Icons.settings_suggest, size: 16),
                        label: const Text('System'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              themeProvider.themeMode == ThemeMode.system
                                  ? Theme.of(context).primaryColor
                                  : null,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
