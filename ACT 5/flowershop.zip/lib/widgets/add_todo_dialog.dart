import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/todo_provider.dart';
import '../models/todo.dart';

class AddTodoDialog extends StatefulWidget {
  final Todo? todo;

  const AddTodoDialog({super.key, this.todo});

  @override
  State<AddTodoDialog> createState() => _AddTodoDialogState();
}

class _AddTodoDialogState extends State<AddTodoDialog> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _categoryController = TextEditingController();

  DateTime? _selectedDueDate;
  bool _isCompleted = false;
  bool _isEditMode = false;

  final List<String> _categories = [
    'General',
    'Watering',
    'Fertilizing',
    'Pruning',
    'Repotting',
    'Pest Control',
    'Seasonal Care',
  ];

  @override
  void initState() {
    super.initState();
    _isEditMode = widget.todo != null;

    if (_isEditMode) {
      _titleController.text = widget.todo!.title;
      _descriptionController.text = widget.todo!.description;
      _categoryController.text = widget.todo!.category;
      _selectedDueDate = widget.todo!.dueDate;
      _isCompleted = widget.todo!.isCompleted;
    } else {
      _categoryController.text = 'General';
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _categoryController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(_isEditMode ? 'Edit Task' : 'Add New Task'),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Task Title',
                  hintText: 'e.g., Water the roses',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter a task title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Description (Optional)',
                  hintText: 'Add more details about this task...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _categoryController.text,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(),
                ),
                items: _categories.map((category) {
                  return DropdownMenuItem(
                    value: category,
                    child: Row(
                      children: [
                        Icon(
                          _getCategoryIcon(category),
                          color: _getCategoryColor(category),
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        Text(category),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _categoryController.text = value ?? 'General';
                  });
                },
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      _selectedDueDate == null
                          ? 'No due date set'
                          : 'Due: ${_formatDate(_selectedDueDate!)}',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                  TextButton.icon(
                    onPressed: _selectDueDate,
                    icon: const Icon(Icons.calendar_today),
                    label:
                        Text(_selectedDueDate == null ? 'Set Date' : 'Change'),
                  ),
                ],
              ),
              if (_selectedDueDate != null) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    TextButton(
                      onPressed: () {
                        setState(() {
                          _selectedDueDate = null;
                        });
                      },
                      child: const Text('Remove Date'),
                    ),
                  ],
                ),
              ],
              if (_isEditMode) ...[
                const SizedBox(height: 16),
                CheckboxListTile(
                  title: const Text('Mark as completed'),
                  value: _isCompleted,
                  onChanged: (value) {
                    setState(() {
                      _isCompleted = value ?? false;
                    });
                  },
                  controlAffinity: ListTileControlAffinity.leading,
                ),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _saveTodo,
          child: Text(_isEditMode ? 'Update' : 'Add'),
        ),
      ],
    );
  }

  void _selectDueDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedDueDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (date != null) {
      setState(() {
        _selectedDueDate = date;
      });
    }
  }

  void _saveTodo() async {
    if (_formKey.currentState!.validate()) {
      final todoProvider = context.read<TodoProvider>();

      final todo = Todo(
        id: _isEditMode
            ? widget.todo!.id
            : DateTime.now().millisecondsSinceEpoch.toString(),
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        isCompleted: _isCompleted,
        createdAt: _isEditMode ? widget.todo!.createdAt : DateTime.now(),
        dueDate: _selectedDueDate,
        category: _categoryController.text,
      );

      if (_isEditMode) {
        await todoProvider.updateTodo(todo);
      } else {
        await todoProvider.addTodo(todo);
      }

      if (mounted) {
        Navigator.pop(context);
      }
    }
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Watering':
        return Icons.water_drop;
      case 'Fertilizing':
        return Icons.eco;
      case 'Pruning':
        return Icons.content_cut;
      case 'Repotting':
        return Icons.local_florist;
      case 'Pest Control':
        return Icons.bug_report;
      case 'Seasonal Care':
        return Icons.wb_sunny;
      case 'General':
      default:
        return Icons.task_alt;
    }
  }

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Watering':
        return Colors.blue;
      case 'Fertilizing':
        return Colors.green;
      case 'Pruning':
        return Colors.orange;
      case 'Repotting':
        return Colors.purple;
      case 'Pest Control':
        return Colors.red;
      case 'Seasonal Care':
        return Colors.amber;
      case 'General':
      default:
        return Colors.grey;
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}
