import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import 'orders/orders_screen.dart';
import 'documents/documents_screen.dart';
import 'admin_products_screen.dart';
import 'customer_management_screen.dart';
import 'analytics_dashboard_screen.dart';

class AdminHomeScreen extends StatelessWidget {
  const AdminHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () =>
                Provider.of<AppState>(context, listen: false).logout(),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome, Admin',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 8),
              Text(
                'This is a simplified admin interface. Add metrics and management tools here.',
                style: Theme.of(context)
                    .textTheme
                    .bodyLarge
                    ?.copyWith(color: Colors.grey[700]),
              ),
              const SizedBox(height: 24),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      const Icon(Icons.attach_money, color: Colors.purple),
                      const SizedBox(width: 8),
                      Text(
                        'Revenue',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const Spacer(),
                      Consumer<AppState>(
                        builder: (context, appState, _) {
                          final total = appState.orders
                              .fold<double>(0.0, (s, o) => s + o.totalAmount);
                          return Text(
                            '₱${total.toStringAsFixed(2)}',
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge
                                ?.copyWith(fontWeight: FontWeight.bold),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Consumer<AppState>(
                builder: (context, appState, _) {
                  return Row(
                    children: [
                      Expanded(
                        child: _AdminStatCard(
                          icon: Icons.shopping_cart,
                          color: Colors.blue,
                          label: 'Orders',
                          value: appState.orders.length.toString(),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _AdminStatCard(
                          icon: Icons.event,
                          color: Colors.green,
                          label: 'Reservations',
                          value: appState.reservations.length.toString(),
                        ),
                      ),
                    ],
                  );
                },
              ),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  _AdminTile(
                    icon: Icons.people_alt,
                    label: 'Customers',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const CustomerManagementScreen()),
                      );
                    },
                  ),
                  _AdminTile(
                    icon: Icons.inventory_2,
                    label: 'Products',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const AdminProductsScreen()),
                      );
                    },
                  ),
                  _AdminTile(
                    icon: Icons.receipt_long,
                    label: 'Orders',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const OrdersScreen()),
                      );
                    },
                  ),
                  _AdminTile(
                    icon: Icons.folder_copy,
                    label: 'Documents',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const DocumentsScreen()),
                      );
                    },
                  ),
                  _AdminTile(
                    icon: Icons.analytics,
                    label: 'Analytics',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const AnalyticsDashboardScreen()),
                      );
                    },
                  ),
                  const _AdminTile(icon: Icons.settings, label: 'Settings'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AdminStatCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final String value;

  const _AdminStatCard({
    required this.icon,
    required this.color,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.copyWith(color: Colors.grey[700])),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AdminTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  const _AdminTile({required this.icon, required this.label, this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 150,
      height: 110,
      child: Card(
        child: InkWell(
          onTap: onTap,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 28, color: Theme.of(context).primaryColor),
                const SizedBox(height: 8),
                Text(label),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
