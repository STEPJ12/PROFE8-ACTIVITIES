import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../models/document.dart';

class DocumentDetailScreen extends StatelessWidget {
  final Document document;

  const DocumentDetailScreen({
    super.key,
    required this.document,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(document.title),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'download':
                  _downloadDocument(context);
                  break;
                case 'edit':
                  _editDocument(context);
                  break;
                case 'archive':
                  _archiveDocument(context);
                  break;
                case 'delete':
                  _showDeleteDialog(context);
                  break;
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'download',
                child: Row(
                  children: [
                    Icon(Icons.download),
                    SizedBox(width: 8),
                    Text('Download'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit),
                    SizedBox(width: 8),
                    Text('Edit'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'archive',
                child: Row(
                  children: [
                    Icon(Icons.archive),
                    SizedBox(width: 8),
                    Text('Archive'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Delete', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Document Header
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        _getTypeIcon(document.type),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                document.title,
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _getTypeText(document.type),
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: Colors.grey[600],
                                    ),
                              ),
                            ],
                          ),
                        ),
                        _StatusChip(status: document.status),
                      ],
                    ),
                    if (document.description.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Text(
                        'Description',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        document.description,
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Document Information
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Document Information',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 16),
                    _InfoItem(
                      label: 'File Name',
                      value: document.fileName,
                    ),
                    _InfoItem(
                      label: 'File Size',
                      value: document.fileSizeFormatted,
                    ),
                    _InfoItem(
                      label: 'File Type',
                      value: document.mimeType,
                    ),
                    _InfoItem(
                      label: 'Created At',
                      value: _formatDateTime(document.createdAt),
                    ),
                    if (document.updatedAt != null)
                      _InfoItem(
                        label: 'Updated At',
                        value: _formatDateTime(document.updatedAt!),
                      ),
                    _InfoItem(
                      label: 'Uploaded By',
                      value: document.uploadedBy ?? 'Unknown',
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Related Information
            if (document.relatedOrderId != null ||
                document.relatedReservationId != null)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Related Information',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                      ),
                      const SizedBox(height: 16),
                      if (document.relatedOrderId != null)
                        _InfoItem(
                          label: 'Related Order',
                          value:
                              'Order #${document.relatedOrderId!.substring(0, 8)}',
                        ),
                      if (document.relatedReservationId != null)
                        _InfoItem(
                          label: 'Related Reservation',
                          value:
                              'Reservation #${document.relatedReservationId!.substring(0, 8)}',
                        ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 16),

            // Tags
            if (document.tags.isNotEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Tags',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                      ),
                      const SizedBox(height: 16),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: document.tags.map((tag) {
                          return Chip(
                            label: Text(tag),
                            backgroundColor: Colors.blue.withOpacity(0.1),
                            labelStyle: TextStyle(
                              color: Colors.blue[700],
                              fontSize: 12,
                            ),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 4,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _downloadDocument(context),
                icon: const Icon(Icons.download),
                label: const Text('Download'),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () => _shareDocument(context),
                icon: const Icon(Icons.share),
                label: const Text('Share'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _getTypeIcon(DocumentType type) {
    IconData iconData;
    Color color;

    switch (type) {
      case DocumentType.invoice:
        iconData = Icons.receipt;
        color = Colors.blue;
        break;
      case DocumentType.receipt:
        iconData = Icons.receipt_long;
        color = Colors.green;
        break;
      case DocumentType.contract:
        iconData = Icons.description;
        color = Colors.purple;
        break;
      case DocumentType.certificate:
        iconData = Icons.verified;
        color = Colors.orange;
        break;
      case DocumentType.photo:
        iconData = Icons.photo;
        color = Colors.pink;
        break;
      case DocumentType.design:
        iconData = Icons.design_services;
        color = Colors.teal;
        break;
      case DocumentType.quote:
        iconData = Icons.request_quote;
        color = Colors.indigo;
        break;
      case DocumentType.other:
        iconData = Icons.insert_drive_file;
        color = Colors.grey;
        break;
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(iconData, color: color, size: 32),
    );
  }

  String _getTypeText(DocumentType type) {
    switch (type) {
      case DocumentType.invoice:
        return 'Invoice';
      case DocumentType.receipt:
        return 'Receipt';
      case DocumentType.contract:
        return 'Contract';
      case DocumentType.certificate:
        return 'Certificate';
      case DocumentType.photo:
        return 'Photo';
      case DocumentType.design:
        return 'Design';
      case DocumentType.quote:
        return 'Quote';
      case DocumentType.other:
        return 'Other';
    }
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.day}/${dateTime.month}/${dateTime.year} at ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  void _downloadDocument(BuildContext context) {
    // Implement document download
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Download functionality would be implemented here'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _editDocument(BuildContext context) {
    // Navigate to edit document screen
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Edit functionality would be implemented here'),
        backgroundColor: Colors.orange,
      ),
    );
  }

  void _archiveDocument(BuildContext context) {
    final updatedDocument = document.copyWith(
      status: DocumentStatus.archived,
      updatedAt: DateTime.now(),
    );
    Provider.of<AppState>(context, listen: false)
        .updateDocument(updatedDocument);
    Navigator.pop(context);
  }

  void _shareDocument(BuildContext context) {
    // Implement document sharing
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Share functionality would be implemented here'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _showDeleteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Document'),
        content: const Text(
            'Are you sure you want to delete this document? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Provider.of<AppState>(context, listen: false)
                  .deleteDocument(document.id);
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final DocumentStatus status;

  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (status) {
      case DocumentStatus.active:
        color = Colors.green;
        break;
      case DocumentStatus.archived:
        color = Colors.orange;
        break;
      case DocumentStatus.deleted:
        color = Colors.red;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        _getStatusText(status),
        style: TextStyle(
          color: color,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  String _getStatusText(DocumentStatus status) {
    switch (status) {
      case DocumentStatus.active:
        return 'Active';
      case DocumentStatus.archived:
        return 'Archived';
      case DocumentStatus.deleted:
        return 'Deleted';
    }
  }
}

class _InfoItem extends StatelessWidget {
  final String label;
  final String value;

  const _InfoItem({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}
