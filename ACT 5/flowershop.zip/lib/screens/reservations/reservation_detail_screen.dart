import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../models/reservation.dart';

class ReservationDetailScreen extends StatelessWidget {
  final Reservation reservation;

  const ReservationDetailScreen({
    super.key,
    required this.reservation,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reservation #${reservation.id.substring(0, 8)}'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'edit':
                  // Navigate to edit reservation screen
                  break;
                case 'delete':
                  _showDeleteDialog(context);
                  break;
                case 'print':
                  // Print reservation
                  break;
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit),
                    SizedBox(width: 8),
                    Text('Edit'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'print',
                child: Row(
                  children: [
                    Icon(Icons.print),
                    SizedBox(width: 8),
                    Text('Print'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Delete', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Reservation Status
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Reservation Status',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 8),
                    _StatusChip(status: reservation.status),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: _InfoItem(
                            label: 'Date',
                            value: _formatDate(reservation.reservationDate),
                          ),
                        ),
                        Expanded(
                          child: _InfoItem(
                            label: 'Time',
                            value: reservation.timeSlot,
                          ),
                        ),
                      ],
                    ),
                    if (reservation.estimatedCost != null)
                      _InfoItem(
                        label: 'Estimated Cost',
                        value:
                            '\$${reservation.estimatedCost!.toStringAsFixed(2)}',
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Customer Information
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Customer Information',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 16),
                    _InfoItem(
                      label: 'Name',
                      value: reservation.customerName,
                    ),
                    _InfoItem(
                      label: 'Email',
                      value: reservation.customerEmail,
                    ),
                    _InfoItem(
                      label: 'Phone',
                      value: reservation.customerPhone,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Event Details
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Event Details',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 16),
                    _InfoItem(
                      label: 'Event Type',
                      value: reservation.eventType,
                    ),
                    if (reservation.specialRequests != null)
                      _InfoItem(
                        label: 'Special Requests',
                        value: reservation.specialRequests!,
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Payment Information
            if (reservation.paymentInfo != null)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Payment Information',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                      ),
                      const SizedBox(height: 16),
                      _InfoItem(
                        label: 'Payment Method',
                        value: _getPaymentMethodText(
                            reservation.paymentInfo!.method),
                      ),
                      _InfoItem(
                        label: 'Payment Status',
                        value: _getPaymentStatusText(
                            reservation.paymentInfo!.status),
                      ),
                      _InfoItem(
                        label: 'Amount',
                        value:
                            '\$${reservation.paymentInfo!.amount.toStringAsFixed(2)}',
                      ),
                      _InfoItem(
                        label: 'Processed At',
                        value:
                            _formatDate(reservation.paymentInfo!.processedAt),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 4,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () {
                  _updateReservationStatus(
                      context, ReservationStatus.cancelled);
                },
                child: const Text('Cancel Reservation'),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  _updateReservationStatus(
                      context, _getNextStatus(reservation.status));
                },
                child: Text(_getNextStatusText(reservation.status)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Reservation'),
        content: const Text(
            'Are you sure you want to delete this reservation? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Provider.of<AppState>(context, listen: false)
                  .deleteReservation(reservation.id);
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _updateReservationStatus(
      BuildContext context, ReservationStatus newStatus) {
    final updatedReservation = reservation.copyWith(
      status: newStatus,
      updatedAt: DateTime.now(),
    );
    Provider.of<AppState>(context, listen: false)
        .updateReservation(updatedReservation);
    Navigator.pop(context);
  }

  ReservationStatus _getNextStatus(ReservationStatus currentStatus) {
    switch (currentStatus) {
      case ReservationStatus.pending:
        return ReservationStatus.confirmed;
      case ReservationStatus.confirmed:
        return ReservationStatus.inProgress;
      case ReservationStatus.inProgress:
        return ReservationStatus.completed;
      case ReservationStatus.completed:
        return ReservationStatus.completed;
      case ReservationStatus.cancelled:
        return ReservationStatus.cancelled;
      case ReservationStatus.noShow:
        return ReservationStatus.noShow;
    }
  }

  String _getNextStatusText(ReservationStatus currentStatus) {
    switch (currentStatus) {
      case ReservationStatus.pending:
        return 'Confirm';
      case ReservationStatus.confirmed:
        return 'Start Event';
      case ReservationStatus.inProgress:
        return 'Complete';
      case ReservationStatus.completed:
        return 'Completed';
      case ReservationStatus.cancelled:
        return 'Cancelled';
      case ReservationStatus.noShow:
        return 'No Show';
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  String _getPaymentMethodText(PaymentMethod method) {
    switch (method) {
      case PaymentMethod.cash:
        return 'Cash';
      case PaymentMethod.card:
        return 'Card';
      case PaymentMethod.bankTransfer:
        return 'Bank Transfer';
      case PaymentMethod.digitalWallet:
        return 'Digital Wallet';
    }
  }

  String _getPaymentStatusText(PaymentStatus status) {
    switch (status) {
      case PaymentStatus.pending:
        return 'Pending';
      case PaymentStatus.processing:
        return 'Processing';
      case PaymentStatus.completed:
        return 'Completed';
      case PaymentStatus.failed:
        return 'Failed';
      case PaymentStatus.refunded:
        return 'Refunded';
    }
  }
}

class _StatusChip extends StatelessWidget {
  final ReservationStatus status;

  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (status) {
      case ReservationStatus.pending:
        color = Colors.orange;
        break;
      case ReservationStatus.confirmed:
        color = Colors.blue;
        break;
      case ReservationStatus.inProgress:
        color = Colors.purple;
        break;
      case ReservationStatus.completed:
        color = Colors.green;
        break;
      case ReservationStatus.cancelled:
        color = Colors.red;
        break;
      case ReservationStatus.noShow:
        color = Colors.grey;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        _getStatusText(status),
        style: TextStyle(
          color: color,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  String _getStatusText(ReservationStatus status) {
    switch (status) {
      case ReservationStatus.pending:
        return 'Pending';
      case ReservationStatus.confirmed:
        return 'Confirmed';
      case ReservationStatus.inProgress:
        return 'In Progress';
      case ReservationStatus.completed:
        return 'Completed';
      case ReservationStatus.cancelled:
        return 'Cancelled';
      case ReservationStatus.noShow:
        return 'No Show';
    }
  }
}

class _InfoItem extends StatelessWidget {
  final String label;
  final String value;

  const _InfoItem({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: Colors.grey[600],
                  ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}
