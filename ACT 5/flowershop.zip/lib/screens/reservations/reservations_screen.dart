import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../models/reservation.dart';
import 'reservation_detail_screen.dart';
import 'new_reservation_screen.dart';

class ReservationsScreen extends StatefulWidget {
  const ReservationsScreen({super.key});

  @override
  State<ReservationsScreen> createState() => _ReservationsScreenState();
}

class _ReservationsScreenState extends State<ReservationsScreen> {
  ReservationStatus? _filterStatus;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AppState>(context, listen: false).loadReservations();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reservations'),
        actions: [
          PopupMenuButton<ReservationStatus?>(
            icon: const Icon(Icons.filter_list),
            onSelected: (status) {
              setState(() {
                _filterStatus = status;
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: null,
                child: Text('All Reservations'),
              ),
              ...ReservationStatus.values.map((status) => PopupMenuItem(
                    value: status,
                    child: Text(_getStatusText(status)),
                  )),
            ],
          ),
        ],
      ),
      body: Consumer<AppState>(
        builder: (context, appState, child) {
          if (appState.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          final filteredReservations = _filterStatus == null
              ? appState.reservations
              : appState.reservations
                  .where((reservation) => reservation.status == _filterStatus)
                  .toList();

          Widget listWidget;
          if (filteredReservations.isEmpty) {
            listWidget = Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.event_outlined,
                    size: 64,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _filterStatus == null
                        ? 'No reservations found'
                        : 'No reservations with status: ${_getStatusText(_filterStatus!)}',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: Colors.grey[600],
                        ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            );
          } else {
            listWidget = ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: filteredReservations.length,
              itemBuilder: (context, index) {
                final reservation = filteredReservations[index];
                return ReservationCard(
                  reservation: reservation,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            ReservationDetailScreen(reservation: reservation),
                      ),
                    );
                  },
                  trailing: _AdminActions(reservation: reservation),
                );
              },
            );
          }

          return Column(
            children: [
              Expanded(child: listWidget),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.event_available),
                    label: const Text('RESERVE NOW'),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const NewReservationScreen(),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          );
        },
      ),
      // The floating action is replaced by a prominent RESERVE NOW button at bottom
    );
  }

  String _getStatusText(ReservationStatus status) {
    switch (status) {
      case ReservationStatus.pending:
        return 'Pending';
      case ReservationStatus.confirmed:
        return 'Confirmed';
      case ReservationStatus.inProgress:
        return 'In Progress';
      case ReservationStatus.completed:
        return 'Completed';
      case ReservationStatus.cancelled:
        return 'Cancelled';
      case ReservationStatus.noShow:
        return 'No Show';
    }
  }
}

class ReservationCard extends StatelessWidget {
  final Reservation reservation;
  final VoidCallback onTap;
  final Widget? trailing;

  const ReservationCard({
    super.key,
    required this.reservation,
    required this.onTap,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Reservation #${reservation.id.substring(0, 8)}',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _StatusChip(status: reservation.status),
                      if (trailing != null) ...[
                        const SizedBox(width: 8),
                        trailing!,
                      ]
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                reservation.customerName,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              const SizedBox(height: 4),
              Text(
                reservation.customerEmail,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey[600],
                    ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(
                    Icons.event,
                    size: 16,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatDate(reservation.reservationDate),
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(width: 16),
                  Icon(
                    Icons.access_time,
                    size: 16,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 4),
                  Text(
                    reservation.timeSlot,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Icon(
                    Icons.celebration,
                    size: 16,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 4),
                  Text(
                    reservation.eventType,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  if (reservation.estimatedCost != null) ...[
                    const Spacer(),
                    Text(
                      '₱${reservation.estimatedCost!.toStringAsFixed(2)}',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).primaryColor,
                          ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}

class _StatusChip extends StatelessWidget {
  final ReservationStatus status;

  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (status) {
      case ReservationStatus.pending:
        color = Colors.orange;
        break;
      case ReservationStatus.confirmed:
        color = Colors.blue;
        break;
      case ReservationStatus.inProgress:
        color = Colors.purple;
        break;
      case ReservationStatus.completed:
        color = Colors.green;
        break;
      case ReservationStatus.cancelled:
        color = Colors.red;
        break;
      case ReservationStatus.noShow:
        color = Colors.grey;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        _getStatusText(status),
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  String _getStatusText(ReservationStatus status) {
    switch (status) {
      case ReservationStatus.pending:
        return 'Pending';
      case ReservationStatus.confirmed:
        return 'Confirmed';
      case ReservationStatus.inProgress:
        return 'In Progress';
      case ReservationStatus.completed:
        return 'Completed';
      case ReservationStatus.cancelled:
        return 'Cancelled';
      case ReservationStatus.noShow:
        return 'No Show';
    }
  }
}

class _AdminActions extends StatelessWidget {
  final Reservation reservation;
  const _AdminActions({required this.reservation});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.more_vert),
      onSelected: (value) async {
        final appState = Provider.of<AppState>(context, listen: false);
        switch (value) {
          case 'confirm':
            await appState.updateReservation(reservation.copyWith(
                status: ReservationStatus.confirmed,
                updatedAt: DateTime.now()));
            break;
          case 'complete':
            await appState.updateReservation(reservation.copyWith(
                status: ReservationStatus.completed,
                updatedAt: DateTime.now()));
            break;
          case 'cancel':
            await appState.updateReservation(reservation.copyWith(
                status: ReservationStatus.cancelled,
                updatedAt: DateTime.now()));
            break;
        }
      },
      itemBuilder: (context) => const [
        PopupMenuItem(value: 'confirm', child: Text('Confirm')),
        PopupMenuItem(value: 'complete', child: Text('Complete')),
        PopupMenuItem(value: 'cancel', child: Text('Cancel')),
      ],
    );
  }
}
