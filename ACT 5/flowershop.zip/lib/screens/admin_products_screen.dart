import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../models/product.dart';

class AdminProductsScreen extends StatelessWidget {
  const AdminProductsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Manage Products')),
      body: Consumer<AppState>(
        builder: (context, appState, _) {
          final products = appState.products;
          if (products.isEmpty) {
            return const Center(child: Text('No products yet'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: products.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final p = products[index];
              return ListTile(
                leading:
                    CircleAvatar(backgroundImage: NetworkImage(p.imageUrl)),
                title: Text(p.name),
                subtitle: Text('₱${p.price.toStringAsFixed(2)}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () async {
                        final updated = await Navigator.push<Product>(
                          context,
                          MaterialPageRoute(
                            builder: (_) => _EditProductScreen(product: p),
                          ),
                        );
                        if (updated != null) {
                          Provider.of<AppState>(context, listen: false)
                              .updateProduct(updated);
                        }
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        Provider.of<AppState>(context, listen: false)
                            .deleteProduct(p.id);
                      },
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await Navigator.push<Product>(
            context,
            MaterialPageRoute(builder: (_) => const _EditProductScreen()),
          );
          if (created != null) {
            Provider.of<AppState>(context, listen: false).addProduct(created);
          }
        },
        icon: const Icon(Icons.add),
        label: const Text('Add Product'),
      ),
    );
  }
}

class _EditProductScreen extends StatefulWidget {
  final Product? product;
  const _EditProductScreen({this.product});

  @override
  State<_EditProductScreen> createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<_EditProductScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name =
      TextEditingController(text: widget.product?.name ?? '');
  late final TextEditingController _desc =
      TextEditingController(text: widget.product?.description ?? '');
  late final TextEditingController _price =
      TextEditingController(text: widget.product?.price.toString() ?? '');
  late final TextEditingController _image =
      TextEditingController(text: widget.product?.imageUrl ?? '');

  @override
  void dispose() {
    _name.dispose();
    _desc.dispose();
    _price.dispose();
    _image.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final isEdit = widget.product != null;
    final product = Product(
      id: isEdit
          ? widget.product!.id
          : DateTime.now().millisecondsSinceEpoch.toString(),
      name: _name.text.trim(),
      description: _desc.text.trim(),
      price: double.tryParse(_price.text.trim()) ?? 0,
      imageUrl: _image.text.trim(),
    );
    Navigator.pop(context, product);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(widget.product == null ? 'Add Product' : 'Edit Product')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Name'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _desc,
              decoration: const InputDecoration(labelText: 'Description'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _price,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Price (₱)'),
              validator: (v) => (double.tryParse(v ?? '') == null)
                  ? 'Enter a valid number'
                  : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _image,
              decoration: const InputDecoration(labelText: 'Image URL'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Required' : null,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _save,
                child: const Text('Save'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
