import 'package:flutter/foundation.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/order.dart';
import '../models/reservation.dart'
    hide PaymentInfo, PaymentMethod, PaymentStatus;
import '../models/document.dart';
import '../models/product.dart';

class AppState extends ChangeNotifier {
  bool _isLoggedIn = false;
  String? _currentUser;
  UserRole _currentRole = UserRole.user;
  List<Order> _orders = [];
  List<Reservation> _reservations = [];
  List<Document> _documents = [];
  bool _isLoading = false;
  // Customer preferences / recipient info
  String _preferredNote = '';
  bool _includeGiftWrap = false;
  bool _subscribeToUpdates = true;
  String _recipientName = '';
  // Shop
  final List<Product> _products = [
    const Product(
      id: 'rose-bouquet',
      name: 'Citrus Grove',
      description:
          'The Citrus Grove bouquet bursts with radiant orange blooms, infusing any space with a zesty pop of color and a refreshing fragrance. Whether as a cheerful gift or a bright centerpiece, it brings the invigorating beauty of nature’s own palette into your world.',
      price: 1499,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/product/350_83CNwlwqok8zvHcihIIn7bLMV.webp',
    ),
    const Product(
      id: 'sunflower-bundle',
      name: 'Bright Red Eternal Love Box',
      description:
          'The Bright Red Eternal Love Box is a stunning expression of enduring affection. This exquisite box, featuring unscented red roses and Ferrero Rocher chocolates, symbolizes the depth of your love. Surprise your partner with this elegant gift today.',
      price: 999,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/product/350_NA8Gb3qAkfpqXVL1RRhUVdDp3.webp',
    ),
    const Product(
      id: 'lily-arrangement',
      name: 'Love in full bloom',
      description:
          'Sweep them off their feet with this breathtaking bouquet of radiant red roses — the ultimate symbol of love and devotion. Whether it’s for an anniversary, a romantic surprise, or simply because, this bouquet is a heartfelt gesture they will never forget. Love in Full Bloom consists of 50 red roses',
      price: 3299,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/variant/600_Q4IBSs1C2D8qWHdctkASN6JZ6.webp',
    ),
    const Product(
      id: 'tulip-bouquet',
      name: 'Sunny Days',
      description:
          'Radiating positivity and charm, Sunny Days is the perfect pick-me-up for moments that call for celebration, or just a little extra sunshine. Designed to brighten hearts and lift spirits, it’s a radiant expression of optimism that never goes unnoticed.',
      price: 2199,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/product/350_idcyKXAOxEP7zVRJF6bfR33Tp.webp',
    ),
    const Product(
      id: 'orchid-stem',
      name: 'Colors of love bundle',
      description:
          'Red roses and a Red Velvet cake in one?! Your partner will surely feel love forevermore with this bouquet. Express your unconditional love for your partner through this Color of Love Bundle by ordering today!',
      price: 3999,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/product/350_u3OQYVw7a8JkYtIMJrPTE9XEm.webp',
    ),
    const Product(
      id: 'peony-delight',
      name: 'Blush Symphony (100 pink roses)',
      description:
          'Soft, romantic, and effortlessly graceful, this bouquet is a poetic expression of tender affection. Perfect for those moments when you want to say "you are cherished" in the gentlest way possible.',
      price: 4999,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/product/350_PxBSERLM9mOtxmpDaOiMeeLr2.webp',
    ),
    const Product(
      id: 'daisy-charm',
      name: 'Citrus Kiss',
      description:
          'Bright and full of zest, Citrus Kiss brings a lively splash of warmth and cheer. With its radiant hues and fresh charm, this bouquet adds a burst of sunshine to any space, making it the perfect choice for uplifting moments and heartfelt celebrations.',
      price: 1999,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/product/350_MOH9ruzUkXWw2oYjgNvZgHAZz.webp',
    ),
    const Product(
      id: 'hydrangea-blue',
      name: 'One in a million',
      description:
          'One In A Million is a grand display of affection, featuring a luxurious velvet box filled with vibrant blooms. This stunning collection of flowers is designed to make your loved one feel truly special and cherished.',
      price: 4999,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/variant/600_axFsWgNClJGz0nkvY4pzCQAqJ.webp',
    ),
    const Product(
      id: 'wildflower-mix',
      name: 'Grazing Chocolate Strawberries with 250ml Red Wine',
      description:
          '“Grazing Chocolate Strawberries with 250ml Red Wine” is an exquisite pairing that harmonizes the luscious sweetness of chocolate-drenched strawberries with the rich complexity of carefully selected red wine. Crafted for those who appreciate the finer things in life, this combination promises a symphony of flavors that delight the palate.',
      price: 3499,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/variant/600_2VtyvNwJoa40WVE2eeEPPBpI4.webp',
    ),
    const Product(
      id: 'succulent-trio',
      name: 'Bloomberry Bright',
      description:
          'Elevate any celebration with this beautifully curated box, featuring decadent white chocolate-covered strawberries. Each berry is hand-dipped to perfection, offering a delightful balance of sweetness and creaminess. Whether shared as a romantic gesture or enjoyed as a luxurious treat, this box is designed to impress with its irresistible flavors and elegant presentation.',
      price: 4199,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/variant/600_CUfqq3PgumEHPyC9B9miJBn5y.webp',
    ),
    const Product(
      id: 'lavender-bundle',
      name: 'Sugar Pie, Honey Bunch',
      description:
          'Sugar Pie, Honey Bunch is the sweetest way to show your special someone how far your love extends. It features 4 stems of Phalaenopsis orchids decorated with preserved florals, arranged in our large signature Capiz shell planter.',
      price: 7699,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/variant/600_hJwq8NlNMeugeXI5u36GCv4xK.webp',
    ),
    const Product(
      id: 'ranunculus-bunch',
      name: 'Memorable Chocolate Monogram',
      description:
          'Celebrate life is sweet moments with the Memorable Chocolate Monogram, a personalized cake that adds a modern touch to any occasion. Suitable for all ages, this cake is a unique expression of personal style, making it the perfect centerpiece for special celebrations. Its chic design and custom monogram create a lasting memory.',
      price: 2399,
      imageUrl:
          'https://assets.flowerstore.ph/public/tenantPH/app/assets/images/variant/600_3scyZVuOyZSrLwrtPG7yoLN63.webp',
    ),
  ];
  final List<CartItem> _cart = [];

  // Getters
  bool get isLoggedIn => _isLoggedIn;
  String? get currentUser => _currentUser;
  UserRole get currentRole => _currentRole;
  List<Order> get orders => _orders;
  List<Reservation> get reservations => _reservations;
  List<Document> get documents => _documents;
  bool get isLoading => _isLoading;
  String get preferredNote => _preferredNote;
  bool get includeGiftWrap => _includeGiftWrap;
  bool get subscribeToUpdates => _subscribeToUpdates;
  String get recipientName => _recipientName;
  List<Product> get products => _products;
  List<CartItem> get cart => _cart;
  double get cartTotal => _cart.fold(0.0, (sum, item) => sum + item.lineTotal);

  // Authentication
  Future<bool> login(String email, String password, {UserRole? role}) async {
    _setLoading(true);
    try {
      // Simulate login - in real app, this would call an API
      await Future.delayed(const Duration(seconds: 1));

      if (email.isNotEmpty && password.isNotEmpty) {
        _isLoggedIn = true;
        _currentUser = email;
        if (role != null) {
          _currentRole = role;
        }
        await loadAllData();
        notifyListeners();
        return true;
      }
      return false;
    } finally {
      _setLoading(false);
    }
  }

  void logout() {
    _isLoggedIn = false;
    _currentUser = null;
    _currentRole = UserRole.user;
    _documents.clear();
    notifyListeners();
  }

  // Orders
  Future<void> loadOrders() async {
    _setLoading(true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('orders');
      if (raw != null) {
        final List data = jsonDecode(raw) as List;
        _orders =
            data.map((e) => Order.fromJson(e as Map<String, dynamic>)).toList();
      }
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> addOrder(Order order) async {
    _setLoading(true);
    try {
      _orders.add(order);
      await _saveOrders();
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> updateOrder(Order order) async {
    _setLoading(true);
    try {
      final index = _orders.indexWhere((o) => o.id == order.id);
      if (index != -1) {
        _orders[index] = order;
        await _saveOrders();
        notifyListeners();
      }
    } finally {
      _setLoading(false);
    }
  }

  Future<void> deleteOrder(String orderId) async {
    _setLoading(true);
    try {
      _orders.removeWhere((o) => o.id == orderId);
      await _saveOrders();
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  // Reservations
  Future<void> loadReservations() async {
    _setLoading(true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('reservations');
      if (raw != null) {
        final List data = jsonDecode(raw) as List;
        _reservations = data
            .map((e) => Reservation.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> addReservation(Reservation reservation) async {
    _setLoading(true);
    try {
      _reservations.add(reservation);
      await _saveReservations();
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> updateReservation(Reservation reservation) async {
    _setLoading(true);
    try {
      final index = _reservations.indexWhere((r) => r.id == reservation.id);
      if (index != -1) {
        _reservations[index] = reservation;
        await _saveReservations();
        notifyListeners();
      }
    } finally {
      _setLoading(false);
    }
  }

  Future<void> deleteReservation(String reservationId) async {
    _setLoading(true);
    try {
      _reservations.removeWhere((r) => r.id == reservationId);
      await _saveReservations();
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  // Documents
  Future<void> loadDocuments() async {
    _setLoading(true);
    try {
      // Simulate loading delay
      await Future.delayed(const Duration(milliseconds: 500));
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> addDocument(Document document) async {
    _setLoading(true);
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      _documents.add(document);
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  Future<void> updateDocument(Document document) async {
    _setLoading(true);
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      final index = _documents.indexWhere((d) => d.id == document.id);
      if (index != -1) {
        _documents[index] = document;
        notifyListeners();
      }
    } finally {
      _setLoading(false);
    }
  }

  Future<void> deleteDocument(String documentId) async {
    _setLoading(true);
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      _documents.removeWhere((d) => d.id == documentId);
      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  List<Document> getFilteredDocuments(DocumentFilter filter) {
    return _documents.where((doc) => filter.matches(doc)).toList();
  }

  // Load all data
  Future<void> loadAllData() async {
    await Future.wait([
      loadOrders(),
      loadReservations(),
      loadDocuments(),
    ]);
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  Future<void> _saveOrders() async {
    final prefs = await SharedPreferences.getInstance();
    final list = _orders.map((o) => o.toJson()).toList();
    await prefs.setString('orders', jsonEncode(list));
  }

  Future<void> _saveReservations() async {
    final prefs = await SharedPreferences.getInstance();
    final list = _reservations.map((r) => r.toJson()).toList();
    await prefs.setString('reservations', jsonEncode(list));
  }

  // Preferences
  void saveOrderPreferences({
    required String note,
    required bool giftWrap,
    required bool subscribe,
  }) {
    _preferredNote = note;
    _includeGiftWrap = giftWrap;
    _subscribeToUpdates = subscribe;
    notifyListeners();
  }

  // Recipient
  void saveRecipientName(String name) {
    _recipientName = name;
    notifyListeners();
  }

  // Cart operations
  void addToCart(Product product) {
    final existing = _cart.where((c) => c.product.id == product.id).toList();
    if (existing.isNotEmpty) {
      existing.first.quantity += 1;
    } else {
      _cart.add(CartItem(product: product));
    }
    notifyListeners();
  }

  void removeFromCart(String productId) {
    _cart.removeWhere((c) => c.product.id == productId);
    notifyListeners();
  }

  void updateCartQuantity(String productId, int quantity) {
    final item = _cart.firstWhere((c) => c.product.id == productId,
        orElse: () => CartItem(product: _products.first));
    if (item.product.id == productId) {
      item.quantity = quantity.clamp(1, 99);
      notifyListeners();
    }
  }

  void clearCart() {
    _cart.clear();
    notifyListeners();
  }

  // Product management (admin)
  void addProduct(Product product) {
    _products.add(product);
    notifyListeners();
  }

  void updateProduct(Product updated) {
    final index = _products.indexWhere((p) => p.id == updated.id);
    if (index != -1) {
      _products[index] = updated;
      notifyListeners();
    }
  }

  void deleteProduct(String productId) {
    _products.removeWhere((p) => p.id == productId);
    notifyListeners();
  }

  // Checkout: convert cart to an Order and store it
  Future<Order> checkoutCart({
    required String customerName,
    required String customerEmail,
    required String customerPhone,
    required String deliveryAddress,
    required String paymentMethod,
  }) async {
    _setLoading(true);
    try {
      final List<OrderItem> items = _cart
          .map((c) => OrderItem(
                productId: c.product.id,
                productName: c.product.name,
                price: c.product.price,
                quantity: c.quantity,
              ))
          .toList();

      final double total =
          items.fold(0.0, (sum, i) => sum + (i.price * i.quantity));

      final order = Order(
        customerName: customerName,
        customerEmail: customerEmail,
        customerPhone: customerPhone,
        deliveryAddress: deliveryAddress,
        items: items,
        totalAmount: total,
        paymentInfo: PaymentInfo(
          paymentId: DateTime.now().millisecondsSinceEpoch.toString(),
          method: _mapPaymentMethod(paymentMethod),
          status: PaymentStatus.completed,
          amount: total,
          processedAt: DateTime.now(),
        ),
        status: OrderStatus.confirmed,
      );

      await addOrder(order);
      clearCart();
      return order;
    } finally {
      _setLoading(false);
    }
  }

  PaymentMethod _mapPaymentMethod(String method) {
    switch (method) {
      case 'GCash':
        return PaymentMethod.digitalWallet;
      case 'Credit/Debit Card':
        return PaymentMethod.card;
      case 'Cash on Delivery':
      default:
        return PaymentMethod.cash;
    }
  }
}

enum UserRole { admin, user }
