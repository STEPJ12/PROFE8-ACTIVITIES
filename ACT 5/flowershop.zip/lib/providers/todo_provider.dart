import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/todo.dart';

class TodoProvider extends ChangeNotifier {
  static const String _todosKey = 'todos';

  List<Todo> _todos = [];

  List<Todo> get todos => List.unmodifiable(_todos);

  List<Todo> get completedTodos =>
      _todos.where((todo) => todo.isCompleted).toList();

  List<Todo> get pendingTodos =>
      _todos.where((todo) => !todo.isCompleted).toList();

  List<String> get categories =>
      _todos.map((todo) => todo.category).toSet().toList();

  int get totalTodos => _todos.length;

  int get completedCount => completedTodos.length;

  int get pendingCount => pendingTodos.length;

  double get completionPercentage {
    if (_todos.isEmpty) return 0.0;
    return (completedCount / totalTodos) * 100;
  }

  TodoProvider() {
    _loadTodos();
  }

  Future<void> _loadTodos() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final todosJson = prefs.getString(_todosKey);

      if (todosJson != null) {
        final List<dynamic> todosList = json.decode(todosJson);
        _todos = todosList.map((json) => Todo.fromJson(json)).toList();
        notifyListeners();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error loading todos: $e');
      }
    }
  }

  Future<void> _saveTodos() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final todosJson =
          json.encode(_todos.map((todo) => todo.toJson()).toList());
      await prefs.setString(_todosKey, todosJson);
    } catch (e) {
      if (kDebugMode) {
        print('Error saving todos: $e');
      }
    }
  }

  Future<void> addTodo(Todo todo) async {
    _todos.add(todo);
    notifyListeners();
    await _saveTodos();
  }

  Future<void> updateTodo(Todo updatedTodo) async {
    final index = _todos.indexWhere((todo) => todo.id == updatedTodo.id);
    if (index != -1) {
      _todos[index] = updatedTodo;
      notifyListeners();
      await _saveTodos();
    }
  }

  Future<void> deleteTodo(String todoId) async {
    _todos.removeWhere((todo) => todo.id == todoId);
    notifyListeners();
    await _saveTodos();
  }

  Future<void> toggleTodo(String todoId) async {
    final index = _todos.indexWhere((todo) => todo.id == todoId);
    if (index != -1) {
      _todos[index] = _todos[index].copyWith(
        isCompleted: !_todos[index].isCompleted,
      );
      notifyListeners();
      await _saveTodos();
    }
  }

  Future<void> markAllCompleted() async {
    for (int i = 0; i < _todos.length; i++) {
      if (!_todos[i].isCompleted) {
        _todos[i] = _todos[i].copyWith(isCompleted: true);
      }
    }
    notifyListeners();
    await _saveTodos();
  }

  Future<void> clearCompleted() async {
    _todos.removeWhere((todo) => todo.isCompleted);
    notifyListeners();
    await _saveTodos();
  }

  Future<void> clearAll() async {
    _todos.clear();
    notifyListeners();
    await _saveTodos();
  }

  List<Todo> getTodosByCategory(String category) {
    return _todos.where((todo) => todo.category == category).toList();
  }

  List<Todo> searchTodos(String query) {
    if (query.isEmpty) return _todos;

    final lowercaseQuery = query.toLowerCase();
    return _todos.where((todo) {
      return todo.title.toLowerCase().contains(lowercaseQuery) ||
          todo.description.toLowerCase().contains(lowercaseQuery) ||
          todo.category.toLowerCase().contains(lowercaseQuery);
    }).toList();
  }

  List<Todo> getOverdueTodos() {
    final now = DateTime.now();
    return _todos.where((todo) {
      return !todo.isCompleted &&
          todo.dueDate != null &&
          todo.dueDate!.isBefore(now);
    }).toList();
  }

  List<Todo> getTodaysTodos() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    return _todos.where((todo) {
      if (todo.dueDate == null) return false;
      final todoDate =
          DateTime(todo.dueDate!.year, todo.dueDate!.month, todo.dueDate!.day);
      return todoDate.isAtSameMomentAs(today);
    }).toList();
  }
}
