import 'package:uuid/uuid.dart';

class Document {
  final String id;
  final String title;
  final String description;
  final DocumentType type;
  final String filePath;
  final String fileName;
  final int fileSize;
  final String mimeType;
  final DocumentStatus status;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final String? relatedOrderId;
  final String? relatedReservationId;
  final String? uploadedBy;
  final List<String> tags;

  Document({
    String? id,
    required this.title,
    required this.description,
    required this.type,
    required this.filePath,
    required this.fileName,
    required this.fileSize,
    required this.mimeType,
    this.status = DocumentStatus.active,
    DateTime? createdAt,
    this.updatedAt,
    this.relatedOrderId,
    this.relatedReservationId,
    this.uploadedBy,
    this.tags = const [],
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'type': type.name,
      'filePath': filePath,
      'fileName': fileName,
      'fileSize': fileSize,
      'mimeType': mimeType,
      'status': status.name,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'relatedOrderId': relatedOrderId,
      'relatedReservationId': relatedReservationId,
      'uploadedBy': uploadedBy,
      'tags': tags,
    };
  }

  factory Document.fromJson(Map<String, dynamic> json) {
    return Document(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      type: DocumentType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => DocumentType.other,
      ),
      filePath: json['filePath'],
      fileName: json['fileName'],
      fileSize: json['fileSize'],
      mimeType: json['mimeType'],
      status: DocumentStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => DocumentStatus.active,
      ),
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt:
          json['updatedAt'] != null ? DateTime.parse(json['updatedAt']) : null,
      relatedOrderId: json['relatedOrderId'],
      relatedReservationId: json['relatedReservationId'],
      uploadedBy: json['uploadedBy'],
      tags: List<String>.from(json['tags'] ?? []),
    );
  }

  Document copyWith({
    String? title,
    String? description,
    DocumentType? type,
    String? filePath,
    String? fileName,
    int? fileSize,
    String? mimeType,
    DocumentStatus? status,
    DateTime? updatedAt,
    String? relatedOrderId,
    String? relatedReservationId,
    String? uploadedBy,
    List<String>? tags,
  }) {
    return Document(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      type: type ?? this.type,
      filePath: filePath ?? this.filePath,
      fileName: fileName ?? this.fileName,
      fileSize: fileSize ?? this.fileSize,
      mimeType: mimeType ?? this.mimeType,
      status: status ?? this.status,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      relatedOrderId: relatedOrderId ?? this.relatedOrderId,
      relatedReservationId: relatedReservationId ?? this.relatedReservationId,
      uploadedBy: uploadedBy ?? this.uploadedBy,
      tags: tags ?? this.tags,
    );
  }

  String get fileSizeFormatted {
    if (fileSize < 1024) {
      return '$fileSize B';
    } else if (fileSize < 1024 * 1024) {
      return '${(fileSize / 1024).toStringAsFixed(1)} KB';
    } else {
      return '${(fileSize / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
  }
}

enum DocumentType {
  invoice,
  receipt,
  contract,
  certificate,
  photo,
  design,
  quote,
  other,
}

enum DocumentStatus {
  active,
  archived,
  deleted,
}

class DocumentFilter {
  final DocumentType? type;
  final DocumentStatus? status;
  final String? searchQuery;
  final DateTime? startDate;
  final DateTime? endDate;
  final String? relatedOrderId;
  final String? relatedReservationId;

  DocumentFilter({
    this.type,
    this.status,
    this.searchQuery,
    this.startDate,
    this.endDate,
    this.relatedOrderId,
    this.relatedReservationId,
  });

  bool matches(Document document) {
    if (type != null && document.type != type) return false;
    if (status != null && document.status != status) return false;
    if (searchQuery != null &&
        !document.title.toLowerCase().contains(searchQuery!.toLowerCase()) &&
        !document.description
            .toLowerCase()
            .contains(searchQuery!.toLowerCase())) {
      return false;
    }
    if (startDate != null && document.createdAt.isBefore(startDate!))
      return false;
    if (endDate != null && document.createdAt.isAfter(endDate!)) return false;
    if (relatedOrderId != null && document.relatedOrderId != relatedOrderId)
      return false;
    if (relatedReservationId != null &&
        document.relatedReservationId != relatedReservationId) return false;
    return true;
  }
}
